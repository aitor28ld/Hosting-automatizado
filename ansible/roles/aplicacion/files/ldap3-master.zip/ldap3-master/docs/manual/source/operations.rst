LDAP Operations
###############

.. toctree::
   :maxdepth: 2

   bind
   unbind
   add
   delete
   modify
   modifydn
   searches
   compare
   abandon
   extended
