DN parsing
##########

tbd
