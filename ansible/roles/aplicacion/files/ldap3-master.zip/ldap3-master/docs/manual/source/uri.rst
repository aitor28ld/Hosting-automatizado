URI parsing
###########

tbd
