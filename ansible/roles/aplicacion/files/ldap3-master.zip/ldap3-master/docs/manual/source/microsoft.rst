Extended Microsoft operations
#############################


Microsoft extended operations are intended for Active Directory::

    extend.microsoft
        extend.microsoft.dir_sync(sync_base, sync_filter, attributes, cookie, object_security, ancestors_first, public_data_only, incremental_values, max_length, hex_guid)
        extend.microsoft.modify_password(user, new_password, old_password=None)
