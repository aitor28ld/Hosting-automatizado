Case Insensitive Dictionary
###########################

tbd
